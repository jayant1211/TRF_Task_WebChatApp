<?php

$con=mysqli_connect('localhost','root','','trf_task_webapp');
if(!$con)
{
    echo "Connection Error".mysqli_connect_error();
}

?>
